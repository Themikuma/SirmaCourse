package com.sirmaitt.javacourse.chatapplication.utility;

/**
 * Holds the names for all the resources for the internationalization process.
 * 
 * @author gdimitrov
 */
public enum ResourceNames {
	Messages, UserInterface, Errors;
}
