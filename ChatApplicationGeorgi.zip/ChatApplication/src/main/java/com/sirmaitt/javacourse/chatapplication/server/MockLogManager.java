package com.sirmaitt.javacourse.chatapplication.server;

/**
 * @author gdimitrov
 */
public class MockLogManager implements LogManager {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void logEvent(String message) {
	}

}
